#
#  Project X₂7 AppController.rb
#

$version = "aes"
bundle = "#{File.dirname(__FILE__)}/x_to_7.bundle"
if File.exist?(bundle)
	require 'x_to_7.bundle'
else
	p "NO BUNDLE #{bundle} !!!\n"
end
require 'xmeml_builder.rb'

class AppController < OSX::NSObject
	ib_outlets :deactivateMenuItem, :open, :quit
	ib_outlets :mainWindow, :deactivateAreaView, :webView, :problemMessage, :closeRegoButton
	ib_outlets :trackOptionsRadioButtons
	ib_outlets :progressPanel, :progressView, :progressIndicator, :progressMessage
	ib_outlets :seqOptionsDialog, :videoRolesTableView, :audioRolesTableView, :enabledClipsRadioButtons, :audioLevelsCheckbox
	
	def initialize
		default_values = { "TrackOptions" => 1, "ClipOptions" => 1, "AudioLevelsOptions" => 1 }
		defaultsController = OSX::NSUserDefaultsController.sharedUserDefaultsController
		defaultsController.setInitialValues(default_values)
		### check for Application Support subfolder
		paths = OSX::NSFileManager.defaultManager.URLsForDirectory_inDomains(OSX::NSApplicationSupportDirectory, OSX::NSUserDomainMask)
		if paths.length > 0
			app_support_subfolder = paths[0].path.stringByExpandingTildeInPath + "/Project Xto7"
			Dir.mkdir(app_support_subfolder) unless File.directory?(app_support_subfolder)
		end
		@xml_file = app_support_subfolder + "/Xto7 Translation.xml"
		@show_open = true
	end
	
	### rego methods ###
	
	def applicationWillFinishLaunching(sender) # applicationWillFinishLaunching: is sent before application:openFile: (so it can deal with a file dropped onto the app icon)
		#puts "applicationWillFinishLaunching"
		check_for_expired_beta()
		if @this_rego[0]["active"]
			# showMainView()
		else
			@deactivateMenuItem.setTitle("Activate...")
			check_for_rego(@this_rego)
		end
		OSX::LetsMove.PFMoveToApplicationsFolderIfNecessary
		# Create a new openPanel every time BUT reuse instance var @savePanel
#		@openPanel = OSX::NSOpenPanel.openPanel
		@savePanel = OSX::NSSavePanel.savePanel
		@fcpxml_paths = Array.new
	end
	
	def showDeactivation
		@webView.setDrawsBackground(false)
		@mainWindow.makeKeyAndOrderFront(self)
		if @deactivateMenuItem.title=="Activate..."
			showActivationView(nil, WEB_APP + "license/" + SKU.gsub(" ", "%20") + "?sn=" + @this_rego[0]["number"].to_s + "&mac=" + MAC) # NEW
		else
			@mainWindow.setMinSize(OSX::NSSize.new(500, 200+22))
			@mainWindow.setMaxSize(OSX::NSSize.new(500, 200+22))
			showActivationView(nil, WEB_APP + "destroy/" + @this_rego[0]["number"].to_s)
		end
		@closeRegoButton.setTitle("Cancel")
	end
	ib_action :showDeactivation # Activate or Deactivate
	
	def showActivationView(frame, url)
		@webView.setDrawsBackground(false)
		@mainWindow.makeKeyAndOrderFront(self)
		@mainWindow.setTitle("Activation")
		# notification
		center = OSX::NSNotificationCenter.defaultCenter
		center.addObserver_selector_name_object(self, :webViewProgressFinished, "WebProgressFinishedNotification", @webView) # name is WebProgressFinishedNotification NOT WebViewProgressFinishedNotification
		@webView.mainFrame.loadRequest( OSX::NSURLRequest.requestWithURL( OSX::NSURL.URLWithString(url) ) )
	end
	
	def webViewProgressFinished(notification)
		if notification.name=="WebProgressFinishedNotification"
			if @webView.mainFrame.dataSource.nil? # in case page doesn't load...
				@webView.mainFrame.stopLoading
				@problemMessage.setHidden(false)
				@webView.setHidden(true)
			else
				get_web_app_response(@webView.mainFrame.dataSource.response.URL)
			end
		end
	end 
	
	def closeActivationView
		if @closeRegoButton.title=="Continue" || @closeRegoButton.title=="Cancel"
			@mainWindow.close
			open_fcpxml(self)
		else
			OSX::NSApp.terminate(self)
		end
	end
	ib_action :closeActivationView # on click of Registration window's Continue button
	
	### end rego methods ###
	
	def application_openFile(sender, file) # file is NSMutableString when drag-and-dropped
		if @this_rego[0]["active"]
			@roles_become_tracks = true
			if @trackOptionsRadioButtons.selectedCell.tag==0
				@roles_become_tracks = false
			end
			@progressPanel.makeKeyAndOrderFront(self)
			@progressIndicator.setIndeterminate(true)
			@progressIndicator.setUsesThreadedAnimation(true)
			@progressIndicator.startAnimation(self)
			@progressMessage.setStringValue("Opening...\n")
			@video_roles_table_checkboxes, @audio_roles_table_checkboxes = Array.new, Array.new
			@videoRolesTableView.reloadData
			@audioRolesTableView.reloadData
			Thread.new { translationDidStart(file) }
			return true
		else
			check_for_rego(@this_rego)
		end
	end

	def applicationDidFinishLaunching(sender) # sent after application:openFile:
		if @show_open
			open_fcpxml(self)
		end
	end
	
	def open_fcpxml(sender)
		openPanel = OSX::NSOpenPanel.openPanel
		openPanel.setTitle("Project X₂7")
		openPanel.setMessage("Choose one or more Event or Project XMLs exported from Final Cut Pro X")
		openPanel.setAllowedFileTypes(["fcpxml", "fcpxmld"])
		openPanel.setAllowsMultipleSelection(true)
		buttonClicked = openPanel.runModal
		if buttonClicked==1 # NSModalResponseOK
			@fcpxml_paths = Array.new
			openPanel.URLs.each do |url|
				@fcpxml_paths << url.path
			end
			file = @fcpxml_paths.shift
			application_openFile(self, file)
		end
	end
	ib_action :open_fcpxml
	
	def translationDidStart(file)
		@file = file
		begin
			@show_open = false
			@xml, $int_dtd, doctype = parse_fcpxml(@file.to_s)
			if doctype=="not fcpxml"
				raise "not fcpxml"
			elsif doctype=="Event"
				@type = "Xto7event"
			else
				@type = "Xto7project"
			end
			@progressMessage.setStringValue("Translating to Final Cut Pro XML...\n")
			translate_from_X_to_7(@file, @xml, @type)
		rescue => e
			@progressPanel.close
			executable = OSX::NSBundle.mainBundle.infoDictionary.objectForKey("CFBundleExecutable")
			version = OSX::NSBundle.mainBundle.infoDictionary.objectForKey("CFBundleShortVersionString")
			alert = OSX::NSAlert.alloc.init
			#puts e.message.inspect
			case e.message
			when "break"
				break
			when "empty", "Document is empty"
				alert.setMessageText("This XML file is empty")
				alert.setInformativeText("Please choose another XML file exported from\nFinal Cut Pro X.")
			when "not fcpxml"
				alert.setMessageText("This is not a Final Cut Pro X XML file")
				alert.setInformativeText("Please choose a .fcpxml file exported from\nFinal Cut Pro X.")
			when "no timeline" 
				alert.setMessageText("There is no Timeline in this XML file")
				alert.setInformativeText("Please choose a Project XML file exported from\nFinal Cut Pro X.")
			when "no assets"
				alert.setMessageText("There are no clips in this Project")
				alert.setInformativeText("Please choose a Project XML file exported from\nFinal Cut Pro X.")
			when "4K" # not used
				alert.setMessageText("Final Cut Pro 7 does not support sequence frame sizes larger than 4000 pixels")
				alert.setInformativeText("Please choose another Project XML file exported from\nFinal Cut Pro X.")
			when "compound clips" # not used
				c_count = e.backtrace.first
				c_names = e.backtrace.last
				if c_count=="1"
					alert.setMessageText("There is a Compound Clip in this Project")
					alert.setInformativeText("Please select this Compound Clip and choose \nClip > Break Apart Clip Items\n\n#{c_names}")
				else
					alert.setMessageText("#{c_count} Compound Clips are in this Project")
					alert.setInformativeText("Please select these Compound Clips and choose \nClip > Break Apart Clip Items\n\n#{c_names}")
				end
			else
				OSX::NSLog("Conversion to xmeml failed: #{e.message}\n#{e.backtrace.join("\n")}")
				alert.setMessageText("There was a problem translating this XML")
				alert.setInformativeText("Please zip up the .fcpxml file and email it with the subject “#{executable} #{version} error” to Xto7@assistedediting.com - thanks for helping us improve #{executable}!")
			end
			alert.setAlertStyle(OSX::NSInformationalAlertStyle)
			alert.runModal
		end
	end
	
	def translationDidFinish(file)
		#puts "translationDidFinish(#{file})"
		@progressMessage.setStringValue("")
		OSX::NSDocumentController.sharedDocumentController.noteNewRecentDocumentURL( OSX::NSURL.fileURLWithPath_isDirectory(file, false) ) # add this file to the Recent menu
		@fcpxml_name = File.basename(file)
		if @event_bins.length==1 && @event_bins.first[:sequences].length==1 # single Project (with or without Event clips) or old Project
			OSX::NSApp.beginSheet_modalForWindow_modalDelegate_didEndSelector_contextInfo(@seqOptionsDialog, @progressPanel, self, nil, nil)
			@videoRolesTableView.reloadData # display @seqOptionsDialog first
			@videoRolesTableView.deselectRow(0)
			@audioRolesTableView.reloadData
			@audioRolesTableView.deselectRow(0)
		else
			@xmeml_sequence_options, @xmeml_enabled_only = false, false
			saveXML()
		end
	end
	
	def selectAllVideoRoles(sender)
		@video_roles_table_checkboxes.each { |x| x[:checkbox] = 1 }
		@videoRolesTableView.reloadData
		@videoRolesTableView.deselectRow(0)
	end
	ib_action :selectAllVideoRoles

	def selectNoVideoRoles(sender)
		@video_roles_table_checkboxes.each { |x| x[:checkbox] = 0 }
		@videoRolesTableView.reloadData
		@videoRolesTableView.deselectRow(0)
	end
	ib_action :selectNoVideoRoles

	def selectAllAudioRoles(sender)
		@audio_roles_table_checkboxes.each { |x| x[:checkbox] = 1 }
		@audioRolesTableView.reloadData
		@audioRolesTableView.deselectRow(0)
	end
	ib_action :selectAllAudioRoles

	def selectNoAudioRoles(sender)
		@audio_roles_table_checkboxes.each { |x| x[:checkbox] = 0 }
		@audioRolesTableView.reloadData
		@audioRolesTableView.deselectRow(0)
	end
	ib_action :selectNoAudioRoles
	
	def closeSeqOptionsDialog(sender)
		OSX::NSApp.endSheet(@seqOptionsDialog)
		@seqOptionsDialog.orderOut(self)
		@xmeml_sequence_options = true
		if @enabledClipsRadioButtons.selectedCell.tag==0
		  @xmeml_enabled_only = true
		else
		  @xmeml_enabled_only = false
		end
		if @audioLevelsCheckbox.state==1
			@keep_audio_levels = true
		else
			@keep_audio_levels = false
		end
		saveXML()
	end
	ib_action :closeSeqOptionsDialog
	
	def saveXML
		xml_name = @fcpxml_name.sub(".fcpxmld", " X₂7.xml").sub(".fcpxml", " X₂7.xml").sub(".FCPXML", " X₂7.xml")
		@savePanel.setMessage("Save the new XML file")
		@savePanel.setNameFieldStringValue(xml_name)
		@savePanel.setAllowedFileTypes(["xml"])
		@savePanel.setExtensionHidden(true)
		@savePanel.setCanSelectHiddenExtension(false)
		@savePanel.beginSheetForDirectory_file_modalForWindow_modalDelegate_didEndSelector_contextInfo(nil, xml_name, @progressPanel, self, 'didEndSaveSheet:returnCode:contextInfo:', nil)
	end

	def didEndSaveSheet_returnCode_contextInfo(sheet, buttonClicked, info)
		if buttonClicked==1 # NSOKButton
			sheet.orderOut(self)
			@progressMessage.setStringValue("Saving Final Cut Pro XML file...\n")
			@progressIndicator.setIndeterminate(true)
			@progressIndicator.setUsesThreadedAnimation(true)
			@progressIndicator.startAnimation(self)
			@progressView.displayIfNeeded
			save_project_xml(sheet.URL.path.to_s)
			if @type=="Xto7project"
				@progressMessage.setStringValue("Saving SRT file...\n")
				@progressView.displayIfNeeded
				new_srt_file = sheet.URL.path.to_s.sub(".xml", ".srt")
				save_project_srt(new_srt_file)
			end
		end
		@progressMessage.setStringValue("")
		@progressIndicator.stopAnimation(self)
		if @fcpxml_paths.empty?
			@progressPanel.close
		else
			file = @fcpxml_paths.shift
			application_openFile(self, file)
		end
	end
	
	def didEndProgressSheet_returnCode_contextInfo(sheet, code, info) # PBF only
		# endSheet then orderOut
		OSX::NSApp.endSheet(sheet)
		sheet.orderOut(self)
		@progressMessage.setStringValue("")
		@progressIndicator.stopAnimation(self)
		OSX::NSApp.dockTile.setBadgeLabel("")
	end
	
	def alertShowHelp(sender) # Compound Clips alert dialog
		openPDF("XtoCC - Help.pdf")
	end
	
	def showHelp(sender)
		openPDF("XtoCC - Help.pdf")
	end
	ib_action :showHelp

	def showHelp2(sender)
		openPDF("Xto7 Activating and Deactivating.pdf")
	end
	ib_action :showHelp2

	def openPDF(filename)
		path_to_pdf = OSX::NSBundle.mainBundle.bundlePath + "/Contents/Resources/#{filename}"
		system('open', path_to_pdf)
	end
	
	def emailSupport(sender)
    executable = OSX::NSBundle.mainBundle.infoDictionary.objectForKey("CFBundleExecutable")
		version = OSX::NSBundle.mainBundle.infoDictionary.objectForKey("CFBundleShortVersionString")
		app = "#{executable} (version #{version})".to_ns.stringByAddingPercentEscapesUsingEncoding(4)
		body = "What went wrong?\n\n\nAttached is the XML file that caused the problem:\n\n\n".to_ns.stringByAddingPercentEscapesUsingEncoding(4)
		mailto = OSX::NSURL.URLWithString("mailto:info@IntelligentAssistance.com?subject=Bug%20Report%20for%20#{app}&body=#{body}")
		result = OSX::NSWorkspace.sharedWorkspace.openURL(mailto)
		if result==false
			contactus = OSX::NSURL.URLWithString("https://intelligentassistance.com/contact-us.html")
			OSX::NSWorkspace.sharedWorkspace.openURL(contactus)
		end
	end
	ib_action :emailSupport

	def visitWebsite(sender)
		system('open', 'http://www.AssistedEditing.com/')
	end
	ib_action :visitWebsite # Help > Visit www.AssistedEditing.com

	#// MARK: - ### NSTableView methods ###
	
	def numberOfRowsInTableView(tableView)
		if tableView.tag==1 # video roles
			if @video_roles_table_checkboxes.nil?
				return 0
			else
				return @video_roles_table_checkboxes.length
			end
		elsif tableView.tag==2 # audio roles
			if @audio_roles_table_checkboxes.nil?
				return 0
			else
				return @audio_roles_table_checkboxes.length
			end
		end
		return 0
	end

	def tableView_objectValueForTableColumn_row(tableView, tableColumn, rowIndex)
		if tableView.tag==1 # video roles
			item = @video_roles_table_checkboxes[rowIndex]
			tableColumn.dataCellForRow(rowIndex).setTitle(item[:role])
			return item[:checkbox]
		elsif tableView.tag==2 # audio roles
			item = @audio_roles_table_checkboxes[rowIndex]
			tableColumn.dataCellForRow(rowIndex).setTitle(item[:role])
			return item[:checkbox]
		end
	end
	
	def tableView_toolTipForCell_rect_tableColumn_row_mouseLocation(tableView, cell, rect, tableColumn, rowIndex, mouseLocation)
		if tableView.tag==1 # video roles
			return @video_roles_table_checkboxes[rowIndex][:role]
		elsif tableView.tag==2 # audio roles
			return @audio_roles_table_checkboxes[rowIndex][:role]
		end
	end

	def tableView_shouldTrackCell_forTableColumn_row(tableView, cell, tableColumn, rowIndex) # triggered by clicking on the row
		role = ""
		subrole = false
		tableView.deselectRow(rowIndex)
		if tableView.tag==1 # video roles
			item = @video_roles_table_checkboxes[rowIndex]
			split = item[:role].split(" ▸ ")
			role = split.first
			if split.length==2
				subrole = true
			end
			if item[:checkbox]==0
				item[:checkbox] = 1
				if subrole==false
					matches = @video_roles_table_checkboxes.find_all { |m| m[:role].include?("#{role} ▸ ") }
					matches.each { |m| m[:checkbox] = 1 }
				end
			else
				item[:checkbox] = 0
				if subrole==false
					matches = @video_roles_table_checkboxes.find_all { |m| m[:role].include?("#{role} ▸ ") }
					matches.each { |m| m[:checkbox] = 0 }
				end
			end
		elsif tableView.tag==2 # audio roles
			item = @audio_roles_table_checkboxes[rowIndex]
			split = item[:role].split(" ▸ ")
			role = split.first
			if split.length==2
				subrole = true
			end
			if item[:checkbox]==0
				item[:checkbox] = 1
				if subrole==false
					matches = @audio_roles_table_checkboxes.find_all { |m| m[:role].include?("#{role} ▸ ") }
					matches.each { |m| m[:checkbox] = 1 }
				end
			else
				item[:checkbox] = 0
				if subrole==false
					matches = @audio_roles_table_checkboxes.find_all { |m| m[:role].include?("#{role} ▸ ") }
					matches.each { |m| m[:checkbox] = 0 }
				end
			end
		end
		tableView.reloadData
		return true
	end

end
