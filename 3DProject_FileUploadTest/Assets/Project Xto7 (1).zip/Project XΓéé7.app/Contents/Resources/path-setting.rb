require 'osx/cocoa'
$ruby_cocoa = true

module RubyCocoaLocations

  def self.set_hierarchical_app_load_paths
    remove_normal_rubycoca_app_paths
    restrict_load_path_to_OSX_defaults
    make_chosen_libs_and_gems_available
    make_app_ruby_files_available
  end

  def self.remove_normal_rubycoca_app_paths
    $:.delete(RubyCocoaLocations.resource_path)
    $:.delete('.')
  end

  def self.restrict_load_path_to_OSX_defaults
    require 'rbconfig'
    $:.delete_if { | p | p =~ Regexp.new(RbConfig::CONFIG['sitedir']) }
    ENV['RUBYLIB'].split(':').each do | path |
      $:.delete(path)
    end if ENV.has_key?('RUBYLIB')
  end

  def self.make_chosen_libs_and_gems_available
    $: << root_for_ruby_files + "/third-party/lib"
    RbConfig::CONFIG['sitelibdir'] = $:.last   # Rubygems uses this
    unless require 'rubygems'
      Gem::ConfigMap[:sitelibdir] = $:.last
    end
    Gem.clear_paths
    ENV['GEM_HOME'] = root_for_ruby_files + "/third-party/rubygems"
    Gem.use_paths(nil, [ENV['GEM_HOME'], APPLE_GEM_HOME]) # Snow Leopard
  end

  def self.make_app_ruby_files_available
    $:.unshift(app_root)
  end

  def self.load_ruby_files
    rbfiles = Dir.chdir(app_root) { Dir["*.rb"] }
    rbfiles.each { |file| require(file) }
  end

  def self.root_for_ruby_files
    if debug_build?
      File.expand_path(resource_path + "/../../../../..")
    else
      resource_path
    end
  end

  def self.app_root
    root_for_ruby_files + "/app"
  end

  def self.debug_build?
    resource_path =~ %r{/build/Debug/\w+.app/}
  end

  def self.resource_path
    OSX::NSBundle.mainBundle.resourcePath.fileSystemRepresentation
  end

end
