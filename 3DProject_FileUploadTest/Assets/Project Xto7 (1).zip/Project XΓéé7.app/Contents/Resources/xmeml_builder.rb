def process_marker_items(clip, marker_items, offset, marker_adj, clipitem_start, clip_duration, order, role, clip_enabled, src_in, clipitem_in, clipitem_out, head_adj, tail_adj, clip_format, displayformat, reel, scene, shot, asset_id, first_frame, custom_metadata)
	#puts "process_marker_items(clip, marker_items, offset=#{offset}, marker_adj=#{marker_adj}, clipitem_start=#{clipitem_start}, clip_duration=#{clip_duration}, order, role, clip_enabled, src_in, clipitem_in, clipitem_out, head_adj, tail_adj, clip_format, displayformat, reel, scene, shot, asset_id, first_frame, custom_metadata)" unless marker_items.empty?
	clip_frameDuration = clip_format[:frameDuration]
	marker_items.each do |marker|
		# FCP7 marker is inside video clip relative to start frame, so has to take into account the video's first frame (start)
		#puts "----------", marker.to_s
		# puts marker.parent.to_s
		#puts "marker's parent:", marker.parent.name.inspect
		#puts "offset = #{offset}, marker_adj = #{marker_adj}"
		case marker.parent.name
		when "clip", "sync-clip"
			# if marker.parent.at_xpath("video").nil? # audio only clip
			# 	offset = 0
			# end
		when "video"
			#puts "WHY IS THIS video???"
		when "audio"
			#puts "WHY IS THIS audio???"
		when "title", "generator", "gap"
			offset = 0 # to_frames(marker.parent["start"], @sequence_settings[:frameDuration])
			marker_adj = -1000 # add 1000/subtract -1000 to compensate for fake in point
		when "transition"
			#puts "offset = #{offset}, marker_adj = #{marker_adj}"
			#puts clip.to_s
		else
			offset = 0
		end
		#puts "offset = #{offset}, marker_adj = #{marker_adj}"
		marker_in = to_frames(marker["start"], @sequence_settings[:frameDuration]) - offset - marker_adj
		#puts "marker_in = to_frames(marker['start'], @sequence_settings[:frameDuration]) - offset - marker_adj = #{to_frames(marker["start"], @sequence_settings[:frameDuration])} - #{offset} - #{marker_adj} = #{marker_in}"
		if marker.parent.name=="transition"
			marker_start = clipitem_start + to_frames(marker["start"], clip_frameDuration) - to_frames("3600s", clip_frameDuration) # marker on a transition is somehow relative to 1hr
			#puts "marker_start = clipitem_start + to_frames(marker['start'], clip_frameDuration) - to_frames('3600s', clip_frameDuration) = #{clipitem_start} + #{to_frames(marker["start"], clip_frameDuration)} - #{to_frames('3600s', clip_frameDuration)} = #{marker_start}"
		else
			marker_start = clipitem_start + to_frames(marker["start"], clip_frameDuration) - to_frames(clip["start"], clip_frameDuration) # marker is in the sequence's frameDuration
			#puts "marker_start = clipitem_start + to_frames(marker['start'], clip_frameDuration) - to_frames(clip['start'], clip_frameDuration) = #{clipitem_start} + #{to_frames(marker["start"], clip_frameDuration)} - #{to_frames(clip["start"], clip_frameDuration)} = #{marker_start}"
		end
		if marker_start.between?(clipitem_start, clipitem_start + clip_duration - 1)
			#puts "visible marker: #{marker_start} between #{clipitem_start} and #{clipitem_start + clip_duration}"
			visible = true
		else
			#puts "invisible marker: #{marker_start} NOT between #{clipitem_start} and #{clipitem_start + clip_duration}"
			visible = false
			#puts clip["start"].inspect
		end
		if marker.name=="marker"
			marker_safe_value = marker["value"].to_s.gsub("<", "&lt;") # nokogiri mangles inner_text containing <
			marker_safe_note = marker["note"].to_s.gsub("<", "&lt;")
			#puts "marker_safe_value = #{marker_safe_value}, marker_safe_note = #{marker_safe_note}"
			case marker["completed"]
			when nil # blue
				@marker_nodes << Nokogiri::XML.fragment("<marker><name>#{marker_safe_value}</name><comment>#{marker_safe_note}</comment><color><alpha>0</alpha><red>0</red><green>128</green><blue>255</blue></color><in>#{marker_in}</in><out>-1</out><pproColor>4294741314</pproColor></marker>").to_s
					@report_markers << { :marker_name => marker["value"], :clip_name => clip["name"], :notes => marker["note"].to_s, :start => marker_start, :type => "standard", :order => order, :role => role, :clip_enabled => clip_enabled, :visible => visible, :src_in => src_in, :clipitem_in => clipitem_in, :clipitem_out => clipitem_out, :head_adj => head_adj, :tail_adj => tail_adj, :clip_frameDuration => clip_format[:frameDuration], :displayformat => displayformat, :first_frame => first_frame, :reel => reel, :scene => scene, :shot => shot } if visible
			when "0" # red
				@marker_nodes << Nokogiri::XML.fragment("<marker><name>#{marker_safe_value}</name><comment>#{marker_safe_note}</comment><color><alpha>0</alpha><red>255</red><green>0</green><blue>0</blue></color><in>#{marker_in}</in><out>-1</out><pproColor>4281740498</pproColor></marker>").to_s
					@report_markers << { :marker_name => marker["value"], :clip_name => clip["name"], :notes => marker["note"].to_s, :start => marker_start, :type => "incomplete to-do", :order => order, :role => role, :clip_enabled => clip_enabled, :visible => visible, :src_in => src_in, :clipitem_in => clipitem_in, :clipitem_out => clipitem_out, :head_adj => head_adj, :tail_adj => tail_adj, :clip_frameDuration => clip_format[:frameDuration], :displayformat => displayformat, :first_frame => first_frame, :reel => reel, :scene => scene, :shot => shot } if visible
			when "1" # green
				@marker_nodes << Nokogiri::XML.fragment("<marker><name>#{marker_safe_value}</name><comment>#{marker_safe_note}</comment><color><alpha>0</alpha><red>48</red><green>191</green><blue>72</blue></color><in>#{marker_in}</in><out>-1</out></marker>").to_s
					@report_markers << { :marker_name => marker["value"], :clip_name => clip["name"], :notes => marker["note"].to_s, :start => marker_start, :type => "completed to-do", :order => order, :role => role, :clip_enabled => clip_enabled, :visible => visible, :src_in => src_in, :clipitem_in => clipitem_in, :clipitem_out => clipitem_out, :head_adj => head_adj, :tail_adj => tail_adj, :clip_frameDuration => clip_format[:frameDuration], :displayformat => displayformat, :first_frame => first_frame, :reel => reel, :scene => scene, :shot => shot } if visible
			end
			# keep track of marker names and the clips' markers
			if visible
				@markers << "#{@report_markers.last[:marker_name]} (#{@report_markers.last[:type].capitalize})"
				@clip_markers << { :marker_name => @markers.last, :start => marker_start }
			end
		elsif marker.name=="chapter-marker" # yellow
			#puts "chapter-marker visible? #{visible}"
			marker_safe_value = marker["value"].to_s.gsub("<", "&lt;") # nokogiri mangles inner_text containing <
			marker_safe_note = marker["note"].to_s.gsub("<", "&lt;")
			@marker_nodes << Nokogiri::XML.fragment("<marker><name>#{marker_safe_value}</name><comment>#{marker_safe_note}</comment><color><alpha>0</alpha><red>255</red><green>255</green><blue>0</blue></color><in>#{marker_in}</in><out>-1</out><pproColor>4281049552</pproColor></marker>").to_s
			@sequence_settings[:marker_nodes] << Nokogiri::XML.fragment("<marker><name>#{marker_safe_value}</name><comment>#{marker_safe_note}</comment><color><alpha>0</alpha><red>255</red><green>255</green><blue>0</blue></color><in>#{marker_start}</in><out>-1</out><pproColor>4281049552</pproColor></marker>").to_s if visible
			already_there = @report_markers.find { |m| m[:start]==marker_start }
			if already_there.nil?
				@report_markers << { :marker_name => marker["value"], :clip_name => clip["name"], :notes => marker["note"].to_s, :start => marker_start, :type => "chapter", :order => order, :role => role, :clip_enabled => clip_enabled, :visible => visible, :src_in => src_in, :clipitem_in => clipitem_in, :clipitem_out => clipitem_out, :head_adj => head_adj, :tail_adj => tail_adj, :clip_frameDuration => clip_format[:frameDuration], :displayformat => displayformat, :first_frame => first_frame, :reel => reel, :scene => scene, :shot => shot } if visible
			else # chapter markers are reported only once...
				already_there[:role] += ", #{role}"
			end
			# keep track of marker names and the clips' markers
			if visible
				# check for first chapter marker in clip to use as thumbnail
				if @clip_markers.find { |m| m[:chapter]==true }.nil?
					#puts "this is the first chapter marker #{marker_safe_value}"
					unless @image_time.nil?
						poster_offset = to_frames(marker["posterOffset"], clip_frameDuration)
						@image_time = (marker_in + to_frames(clip["start"], clip_frameDuration) + poster_offset) * to_rational(clip_format[:frameDuration])
						#puts "  @image_time = (#{marker_in} + #{poster_offset}) * to_rational(#{clip_format[:frameDuration]}) = #{@image_time}"
					end
				else
					#puts "this is NOT the first chapter marker #{marker_safe_value}"
				end
				@markers << "#{@report_markers.last[:marker_name]} (#{@report_markers.last[:type].capitalize})"
				@clip_markers << { :marker_name => @markers.last, :start => marker_start, :chapter => true }
			end
		else # keyword, rating or shot-marker (content auto-analysis)
			marker_duration = to_frames(marker["duration"], clip_frameDuration)
			if marker_start < clipitem_start # marker starts before clip
				marker_duration -= (clipitem_start - marker_start)
				marker_start = clipitem_start
			end
			if (marker_start + marker_duration) > (clipitem_start + clip_duration) # marker ends after clip
				marker_end = clipitem_start + clip_duration
			else
				marker_end = marker_start + marker_duration
			end
			#puts "marker_start #{marker_start.inspect} - marker_end #{marker_end.inspect}"
			#puts "marker_start.between?(#{clipitem_start}, #{clipitem_start + clip_duration - 1}) && marker_end.between?(#{clipitem_start}, #{clipitem_start + clip_duration - 1})"
			if marker_start.between?(clipitem_start, clipitem_start + clip_duration) && marker_end.between?(clipitem_start, clipitem_start + clip_duration) # it's visible (for keywords we're only reporting those on the range of the clip)
				case marker.name
				when "keyword" # turquoise?
					#puts "add keyword"
					marker["value"].split(", ").each do |keyword| # value is a comma-separated list of keywords if they cover the same range
						@keywords << keyword
						markers_in_keyword = @clip_markers.find_all { |m| m[:start].between?(marker_start, marker_end) }
						@report_keywords << { :keyword_name => keyword, :clip_name => clip["name"], :start => marker_start, :end => marker_end, :order => order, :role => role, :clip_enabled => clip_enabled, :asset_id => asset_id, :notes => marker["note"].to_s, :clip_frameDuration => clip_format[:frameDuration], :displayformat => displayformat, :first_frame => first_frame, :reel => reel, :scene => scene, :shot => shot, :markers => markers_in_keyword.collect { |m| m[:marker_name] }, :custom_metadata => custom_metadata }
					end
				when "rating"
					markers_in_keyword = @clip_markers.find_all { |m| m[:start].between?(marker_start, marker_end) }
					if marker["value"]=="favorite"
						if marker["name"].nil?
							keyword = "Favorite"
						else
							keyword = marker["name"]
						end
						#puts "add favorite #{keyword}"
						@report_ratings << { :keyword_name => keyword, :clip_name => clip["name"], :type => "favorite", :start => marker_start, :end => marker_end, :order => order, :role => role, :clip_enabled => clip_enabled, :asset_id => asset_id, :notes => marker["note"].to_s, :clip_frameDuration => clip_format[:frameDuration], :displayformat => displayformat, :first_frame => first_frame, :reel => reel, :scene => scene, :shot => shot, :markers => markers_in_keyword.collect { |m| m[:marker_name] }, :custom_metadata => custom_metadata }
					else # reject
						if marker["name"].nil?
							keyword = "Rejected"
						else
							keyword = marker["name"]
						end
						#puts "add rejected"
						@report_ratings << { :keyword_name => keyword, :clip_name => clip["name"], :type => "reject", :start => marker_start, :end => marker_end, :order => order, :role => role, :clip_enabled => clip_enabled, :asset_id => asset_id, :notes => marker["note"].to_s, :clip_frameDuration => clip_format[:frameDuration], :displayformat => displayformat, :first_frame => first_frame, :reel => reel, :scene => scene, :shot => shot, :markers => markers_in_keyword.collect { |m| m[:marker_name] }, :custom_metadata => custom_metadata }
					end
				when "shot-marker", "analysis-marker" # shot-marker became analysis-marker in 1.4
					values = Array.new
					marker.xpath("shot-type | stabilization-type").each do |st|
						v = st["value"].split(/(?=[A-Z])/)
						v.first.capitalize!
						values << v.join(" ")
					end
					@report_keywords << { :keyword_name => values.join(", "), :clip_name => clip["name"], :type => "analysis", :start => marker_start, :end => marker_end, :order => order, :role => role, :clip_enabled => clip_enabled, :asset_id => asset_id, :notes => marker["note"].to_s, :clip_frameDuration => clip_format[:frameDuration], :displayformat => displayformat, :first_frame => first_frame, :reel => reel, :scene => scene, :shot => shot, :markers => [], :custom_metadata => custom_metadata }
				end
			else
				#puts "keyword is not visible!!!"
			end
		end
		#puts "done with #{marker.name}"
	end # end .each do |marker|
	@sequence_settings[:marker_nodes].uniq! unless @sequence_settings[:marker_nodes].nil?
end

def save_project_xml(xml_file, delete="FALSE")
	#puts "------------------------------------------ save_project_xml"
	unless $ruby_cocoa==false
		# @progressIndicator.setIndeterminate(true)
		# @progressIndicator.setUsesThreadedAnimation(true)
		# @progressIndicator.startAnimation(self)
		# @progressMessage.setStringValue("Saving XML...\n")
		# @progressIndicator.displayIfNeeded
		# @progressView.displayIfNeeded
	end
	begin
		builder = Nokogiri::XML::Builder.new do |xmeml|
      executable = OSX::NSBundle.mainBundle.infoDictionary.objectForKey("CFBundleExecutable")
			version = OSX::NSBundle.mainBundle.infoDictionary.objectForKey("CFBundleShortVersionString")
			xmeml.comment(" #{executable} v#{version}, #{Time.now.strftime("%Y-%m-%d")} ") unless executable.nil?
			xmeml.doc.create_internal_subset("xmeml", nil, nil)
			xmeml.xmeml(:version => "5") {
				@event_bins.each do |bin|
					xmeml.bin {
						#puts bin[:name]
						xmeml.name bin[:name]
						xmeml.children {
							#puts "MASTERS"
							bin[:clips].each_with_index do |c, i|
								asset = @assets.find { |a| a[:id]==c[:asset_id] }
								unless asset.nil? # ignore junk
									xmeml.clip(:id => "masterclip-#{asset[:id]}") {
										xmeml.name c[:name] # or asset[:name]?
										xmeml.duration asset[:duration]
										ntsc, timebase = to_ntsc_timebase(asset[:frameDuration])
										xmeml.rate {
											xmeml.ntsc ntsc
											xmeml.timebase timebase
										}
										xmeml.in "-1"
										xmeml.out "-1"
										xmeml.masterclipid "masterclip-#{asset[:id]}"
										xmeml.ismasterclip "TRUE"
										xmeml.logginginfo {
											xmeml.description c[:role] unless c[:role].nil? # FIXME can't use role because it's different between the video and audio of the same clip
											xmeml.scene c[:scene] unless c[:scene].nil?
											xmeml.shottake c[:shot] unless c[:shot].nil?
											xmeml.lognote c[:notes] unless c[:notes].nil?
										}
										xmeml.comments {
											xmeml.mastercomment1 c[:mc1] unless c[:mc1].nil?
											xmeml.mastercomment2 c[:mc2] unless c[:mc2].nil?
											xmeml.mastercomment3 c[:mc3] unless c[:mc3].nil?
										}
										xmeml.media {
											if asset[:type]=="av" || asset[:type]=="v"
												xmeml.video {
													xmeml.track {
														xmeml.clipitem(:id => "clip-#{asset[:id]}-V") {
															xmeml.masterclipid "masterclip-#{asset[:id]}"
															xmeml.file(:id => "file-#{asset[:id]}") {
																xmeml.name asset[:name]
																xmeml.rate {
																	xmeml.ntsc ntsc
																	xmeml.timebase timebase
																}
																if asset[:opt_src].nil? || asset[:opt_src].empty?
																	unless asset[:src].empty?
																		path = asset[:src].sub("file:///Users/", "file://localhost/Users/")
																		xmeml.pathurl path
																	end
																else
																	path = asset[:opt_src].sub("file:///Users/", "file://localhost/Users/")
																	xmeml.pathurl path
																end
																xmeml.timecode {
																	xmeml.rate {
																		xmeml.ntsc ntsc #unless timebase==24
																		xmeml.timebase timebase
																	}
																	# xmeml.string to_timecode(asset[:start], timebase, asset[:displayformat])
																	xmeml.frame asset[:start]
																	xmeml.source "source"
																	# xmeml.displayformat asset[:displayformat] # assets do not have a displayformat
																	if c[:reel].nil?
																	else
																		xmeml.reel {
																			xmeml.name c[:reel]
																		}
																	end
																}
																xmeml << asset[:media]
															}
														}
													}
												}
											end
											if asset[:type]=="av" || asset[:type]=="a"
												xmeml.audio {
													xmeml.in "-1"
													xmeml.out "-1"
													asset[:audio_tracks].times do |x|
														xmeml.track {
															xmeml.clipitem(:id => "clip-#{asset[:id]}-A#{x+1}") {
																xmeml.masterclipid "masterclip-#{asset[:id]}"
																xmeml.file(:id => "file-#{asset[:id]}") {
																	xmeml.name asset[:name]
																	if File.extname(asset[:src]).downcase==".mp3"
																		ntsc = "TRUE"
																		timebase = 30
																	end
																	xmeml.rate {
																		xmeml.ntsc ntsc
																		xmeml.timebase timebase
																	}
																	if asset[:opt_src].nil? || asset[:opt_src].empty?
																		unless asset[:src].empty?
																			path = asset[:src].sub("file:///Users/", "file://localhost/Users/")
																			xmeml.pathurl path
																		end
																	else
																		path = asset[:opt_src].sub("file:///Users/", "file://localhost/Users/")
																		xmeml.pathurl path
																	end
																	xmeml.timecode {
																		xmeml.rate {
																			xmeml.ntsc ntsc #unless timebase==24
																			xmeml.timebase timebase
																		}
																		# xmeml.string to_timecode(asset[:start], timebase, asset[:displayformat])
																		xmeml.frame asset[:start]
																		xmeml.source "source"
																		# xmeml.displayformat asset[:displayformat]
																		if c[:reel].nil?
																		else
																			xmeml.reel {
																				xmeml.name c[:reel]
																			}
																		end
																	}
																	xmeml << asset[:media]
																}
															}
														}
													end
												}
											end
										}
										asset[:marker_nodes].each do |marker|
											xmeml << marker
										end
									}
								end
							end # bin[:clips].each_with_index
							keyword_bins, subclip_keywords = Array.new, Array.new # subclip_keywords is a dup of bin[:keywords] with :role and :order removed so it can be uniq!ed
							bin[:keywords].each do |k|
								keyword_bins << k[:name]
								subclip_keywords << k.dup
								subclip_keywords.last[:role] = nil
								subclip_keywords.last[:order] = nil
							end
							keyword_bins.uniq!
							subclip_keywords.uniq!
							#puts "KEYWORDS"
							keyword_bins.each_with_index do |keyword_bin, j|
								xmeml.bin {
									xmeml.name keyword_bin
									#puts keyword_bin
									xmeml.children {
										keyword_subset = subclip_keywords.find_all { |s| s[:name]==keyword_bin } # just the subclips with this bin's keyword
										keyword_subset.each_with_index do |keyword, k|
											asset = @assets.find { |a| a[:id]==keyword[:asset_id] }
											if asset.nil?
												xmeml.comment "No asset for #{keyword[:asset_id]}"
											else
												same_subclip_range = subclip_keywords.find_all { |s| s[:asset_id]==keyword[:asset_id] && s[:start]==keyword[:start] && s[:end]==keyword[:end] }
												if same_subclip_range.length > 1
													same_subclip_range.each_with_index do |same, x|
														same[:end] += x
													end
												end
												subclip_id = "subclip-#{asset[:id]}-#{j}-#{k}"
												subclip_master_id = "masterclip-#{asset[:id]}"
												xmeml.clip(:id => subclip_id) {
													xmeml.name keyword[:clip_name]
													xmeml.duration keyword[:end]-keyword[:start]
													xmeml.comment asset[:duration]
													ntsc, timebase = to_ntsc_timebase(asset[:frameDuration])
													xmeml.rate {
														xmeml.ntsc ntsc
														xmeml.timebase timebase
													}
													xmeml.in "-1"
													xmeml.out "-1"
													xmeml.masterclipid subclip_id
													xmeml.subclipmasterid subclip_master_id
													xmeml.ismasterclip "TRUE"
													xmeml.logginginfo {
														xmeml.description keyword[:role] unless keyword[:role].nil?
														xmeml.scene keyword[:scene] unless keyword[:scene].nil?
														xmeml.shottake keyword[:shot] unless keyword[:shot].nil?
														xmeml.lognote keyword[:notes] unless keyword[:notes].nil? # lognote from the keyword's note instead of clip's note
													}
													xmeml.media {
														if asset[:type]=="av" || asset[:type]=="v"
															xmeml.video {
																xmeml.track {
																	xmeml.clipitem(:id => "#{subclip_id}-V") {
																		xmeml.duration keyword[:end]-keyword[:start]
																		xmeml.rate {
																			xmeml.ntsc ntsc
																			xmeml.timebase timebase
																		}
																		xmeml.in "0"
																		xmeml.out keyword[:end]-keyword[:start]
																		xmeml.start "0"
																		xmeml.end keyword[:end]-keyword[:start]
																		xmeml.subclipinfo {
																			xmeml.startoffset keyword[:start]
																			xmeml.endoffset asset[:duration]-keyword[:end]+1
																		}
																		xmeml.masterclipid subclip_id
																		xmeml.subclipmasterid subclip_master_id
																		xmeml.file(:id => "file-#{asset[:id]}")
																	}
																}
															}
														end
														if asset[:type]=="av" || asset[:type]=="a"
															xmeml.audio {
																xmeml.in "-1"
																xmeml.out "-1"
																asset[:audio_tracks].times do |i|
																	xmeml.track {
																		xmeml.clipitem(:id => "#{subclip_id}-A#{i+1}") {
																			xmeml.duration keyword[:end]-keyword[:start]
																			xmeml.rate {
																				xmeml.ntsc ntsc
																				xmeml.timebase timebase
																			}
																			xmeml.in "0"
																			xmeml.out keyword[:end]-keyword[:start]
																			xmeml.start "0"
																			xmeml.end keyword[:end]-keyword[:start]
																			xmeml.subclipinfo {
																				xmeml.startoffset keyword[:start]
																				xmeml.endoffset asset[:duration]-keyword[:end]+1
																			}
																			xmeml.masterclipid subclip_id
																			xmeml.subclipmasterid subclip_master_id
																			xmeml.file(:id => "file-#{asset[:id]}")
																		}
																	}
																end
															}
														end
													}
												}
											end
										end
									}
								}
							end # keyword_bins.each
							#puts "SEQUENCES"
							add_link_string = true
							selected_v_roles, selected_a_roles = Array.new, Array.new
							@video_roles_table_checkboxes.each do |hash|
								if hash[:checkbox]==1
									selected_v_roles << hash[:role]
								else
									add_link_string = false
								end
							end
							@audio_roles_table_checkboxes.each do |hash|
								if hash[:checkbox]==1
									selected_a_roles << hash[:role]
								else
									add_link_string = false
								end
							end
							ignore_all_video = false
							ignore_all_video = true if @xmeml_sequence_options && selected_v_roles.empty?
							ignore_all_audio = false
							ignore_all_audio = true if @xmeml_sequence_options && selected_a_roles.empty?
							#puts "@xmeml_sequence_options = #{@xmeml_sequence_options}, ignore_all_video = #{ignore_all_video}, ignore_all_audio = #{ignore_all_audio}"
							#puts "#{bin[:sequences].length} bin sequences"
							bin[:sequences].each do |seq|
								sequence_settings = seq[:settings]
								if sequence_settings[:width].nil? # audio-only
									sequence_settings[:width] = 320
									sequence_settings[:height] = 240
								end
								unless sequence_settings[:seq_id].nil?
									xmeml.sequence(:id => sequence_settings[:seq_id]) {
										xmeml.updatebehavior "add"
										xmeml.name sequence_settings[:name]
										xmeml.duration sequence_settings[:duration]
										xmeml.rate {
											xmeml.ntsc sequence_settings[:ntsc]
											xmeml.timebase sequence_settings[:timebase]
										}
										xmeml.timecode {
											xmeml.rate {
												xmeml.ntsc sequence_settings[:ntsc]
												xmeml.timebase sequence_settings[:timebase]
											}
											xmeml.string to_timecode(sequence_settings[:frame], sequence_settings[:timebase], sequence_settings[:displayformat])
											xmeml.frame sequence_settings[:frame]
											xmeml.source "source"
											xmeml.displayformat sequence_settings[:displayformat]
										}
										xmeml.in "-1"
										xmeml.out "-1"
										xmeml.media {
											unless ignore_all_video
												xmeml.video {
													xmeml.format {
														xmeml.samplecharacteristics {
															xmeml.width sequence_settings[:width]
															xmeml.height sequence_settings[:height]
															xmeml.anamorphic sequence_settings[:anamorphic]
															xmeml.pixelaspectratio sequence_settings[:pixelaspectratio] unless sequence_settings[:pixelaspectratio].nil?
															xmeml.fielddominance sequence_settings[:fielddominance]
															xmeml.rate {
																xmeml.ntsc sequence_settings[:ntsc]
																xmeml.timebase sequence_settings[:timebase]
															}
															xmeml.colordepth "24"
															xmeml.comment(sequence_settings[:codec]) # NEW
														}
													}
													seq[:videos].each_with_index do |track, t|
														#puts "track V#{t+1} has #{track.length} clips"
														options = {}
														if @roles_become_tracks
															options["MZ.TrackName"] = track.first[:role]
															options["TL.SQTrackExpandedHeight"] = "50"
														end
														xmeml.track(options) {
															track.each_with_index do |clip, c|
																if clip[:name]=="gap"
																	add_this_clip = false
																else
																	add_this_clip = true
																end
																if @xmeml_sequence_options # single Project only
																	if clip[:role].nil? || selected_v_roles.include?(clip[:role])
																		if @xmeml_enabled_only && clip[:clip_enabled]!=nil && clip[:clip_enabled]=="FALSE"
																			add_this_clip = false
																		end
																	else
																		add_this_clip = false
																	end
																end
																#puts " #{clip[:name]}, #{clip[:role].inspect}: '#{clip[:clip_name]}' add_this_clip? #{add_this_clip}"
																if add_this_clip
																	if clip[:lane].to_i < -1
																		clip[:clip_enabled] = "FALSE" # disable video below compositor lane
																	end
																	case clip[:name]
																	when "clip", "sync-clip", "mc-clip"
																		asset = @assets.find { |a| a[:id]==clip[:asset_id] }
																		unless asset.nil?
																			xmeml.clipitem(:id => clip[:clipitem_ids][0]) {
																				clip[:clipitem_ids].delete_at(0)
																				xmeml.name clip[:clip_name]
																				xmeml.duration clip[:clip_duration]
																				xmeml.rate {
																					xmeml.ntsc sequence_settings[:ntsc]
																					xmeml.timebase sequence_settings[:timebase]
																				}
																				if clip[:clipitem_start]>=0
																					xmeml.in clip[:clipitem_in]
																					xmeml.out clip[:clipitem_out]
																					xmeml.start clip[:clipitem_start]
																					xmeml.end clip[:clipitem_end]
																				else
																					xmeml.in clip[:clipitem_in] - clip[:clipitem_start]
																					xmeml.out clip[:clipitem_out]
																					xmeml.start "0"
																					xmeml.end clip[:clipitem_end]
																				end
																				xmeml.compositemode clip[:composite_mode] unless clip[:composite_mode].nil?
																				xmeml.logginginfo {
																					xmeml.description clip[:role]
																					xmeml.scene clip[:scene] unless clip[:scene].nil?
																					xmeml.shottake clip[:shot] unless clip[:shot].nil?
																					xmeml.lognote clip[:notes] unless clip[:notes].nil?
																				}
																				xmeml.comments {
																					xmeml.mastercomment1 clip[:mc1] unless clip[:mc1].nil?
																					xmeml.mastercomment2 clip[:mc2] unless clip[:mc2].nil?
																					xmeml.mastercomment3 clip[:mc3] unless clip[:mc3].nil?
																				}
																				xmeml.enabled clip[:clip_enabled]
																				if asset[:used]
																					xmeml.file(:id => clip[:asset_id])
																				else
																					asset[:used] = true
																					xmeml.file(:id => clip[:asset_id]) {
																						xmeml.name asset[:name]
																						ntsc, timebase = to_ntsc_timebase(clip[:clip_frameDuration])
																						xmeml.rate {
																							xmeml.ntsc ntsc
																							xmeml.timebase timebase
																						}
																						if clip[:opt_src].nil? || clip[:opt_src].empty?
																							unless clip[:src].empty?
																								path = clip[:src].sub("file:///Users/", "file://localhost/Users/")
																								xmeml.pathurl path
																							end
																						else
																							path = clip[:opt_src].sub("file:///Users/", "file://localhost/Users/")
																							xmeml.pathurl path
																						end
																						xmeml.timecode {
																							xmeml.rate {
																								xmeml.ntsc ntsc
																								xmeml.timebase timebase
																							}
																							xmeml.string to_timecode(clip[:first_frame], timebase, clip[:displayformat])
																							xmeml.frame clip[:first_frame]
																							xmeml.source "source"
																							xmeml.displayformat clip[:displayformat]
																							if clip[:reel].nil?
																							else
																								xmeml.reel {
																									xmeml.name clip[:reel]
																								}
																							end
																						}
																						xmeml << clip[:media]
																					}
																				end
																				xmeml << clip[:timeremap_filter]
																				xmeml.filter {
																					xmeml.effect {
																						xmeml.effectid "basic"
																						xmeml.effectcategory "motion"
																						xmeml.effecttype "motion"
																						xmeml.mediatype "video"
																						#pp clip[:scale]
																						if clip[:scale][:value]!=nil
																							xmeml.parameter {
																								xmeml.parameterid "scale"
																								xmeml.name "Scale"
																								xmeml.value clip[:scale][:value]
																								clip[:scale][:keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value kf[:value]
																									}
																								end
																							}
																						end
																						unless clip[:rotation][:value].nil?
																							xmeml.parameter {
																								xmeml.parameterid "rotation"
																								xmeml.name "Rotation"
																								xmeml.value clip[:rotation][:value]
																								clip[:rotation][:keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value kf[:value]
																									}
																								end
																							}
																						end
																						unless clip[:center][:value].nil?
																							xmeml.parameter {
																								xmeml.parameterid "center"
																								xmeml.name "Center"
																								xmeml.value {
																									xmeml.horiz clip[:center][:value].first
																									xmeml.vert clip[:center][:value].last
																								}
																								clip[:center][:keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value {
																											xmeml.horiz kf[:value].first
																											xmeml.vert kf[:value].last
																										}
																									}
																								end
																							}
																						end
																					}
																				}
																				unless clip[:trim].nil?
																					xmeml.filter {
																						xmeml.effect {
																							xmeml.name "Crop"
																							xmeml.effectid "crop"
																							xmeml.effectcategory "motion"
																							xmeml.effecttype "motion"
																							xmeml.mediatype "video"
																							xmeml.parameter {
																								xmeml.parameterid "left"
																								xmeml.name "left"
																								xmeml.value clip[:trim][:left]
																								clip[:trim][:left_keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value kf[:value]
																									}
																								end
																							}
																							xmeml.parameter {
																								xmeml.parameterid "right"
																								xmeml.name "right"
																								xmeml.value clip[:trim][:right]
																								clip[:trim][:right_keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value kf[:value]
																									}
																								end
																							}
																							xmeml.parameter {
																								xmeml.parameterid "top"
																								xmeml.name "top"
																								xmeml.value clip[:trim][:top]
																								clip[:trim][:top_keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value kf[:value]
																									}
																								end
																							}
																							xmeml.parameter {
																								xmeml.parameterid "bottom"
																								xmeml.name "bottom"
																								xmeml.value clip[:trim][:bottom]
																								clip[:trim][:bottom_keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value kf[:value]
																									}
																								end
																							}
																						}
																					}
																				end
																				unless clip[:distort].nil?
																					xmeml.filter {
																						xmeml.effect {
																							xmeml.name "Distort"
																							xmeml.effectid "deformation"
																							xmeml.effectcategory "motion"
																							xmeml.effecttype "motion"
																							xmeml.mediatype "video"
																							xmeml.parameter {
																								xmeml.parameterid "ulcorner"
																								xmeml.name "Upper Left"
																								xmeml.value {
																									xmeml.horiz clip[:distort][:ulcorner].first
																									xmeml.vert clip[:distort][:ulcorner].last
																								}
																								clip[:distort][:ulcorner_keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value {
																											xmeml.horiz kf[:value].first
																											xmeml.vert kf[:value].last
																										}
																									}
																								end
																							}
																							xmeml.parameter {
																								xmeml.parameterid "urcorner"
																								xmeml.name "Upper Right"
																								xmeml.value {
																									xmeml.horiz clip[:distort][:urcorner].first
																									xmeml.vert clip[:distort][:urcorner].last
																								}
																								clip[:distort][:urcorner_keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value {
																											xmeml.horiz kf[:value].first
																											xmeml.vert kf[:value].last
																										}
																									}
																								end
																							}
																							xmeml.parameter {
																								xmeml.parameterid "lrcorner"
																								xmeml.name "Lower Right"
																								xmeml.value {
																									xmeml.horiz clip[:distort][:lrcorner].first
																									xmeml.vert clip[:distort][:lrcorner].last
																								}
																								clip[:distort][:lrcorner_keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value {
																											xmeml.horiz kf[:value].first
																											xmeml.vert kf[:value].last
																										}
																									}
																								end
																							}
																							xmeml.parameter {
																								xmeml.parameterid "llcorner"
																								xmeml.name "Lower Left"
																								xmeml.value {
																									xmeml.horiz clip[:distort][:llcorner].first
																									xmeml.vert clip[:distort][:llcorner].last
																								}
																								clip[:distort][:llcorner_keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value {
																											xmeml.horiz kf[:value].first
																											xmeml.vert kf[:value].last
																										}
																									}
																								end
																							}
																						}
																					}
																				end
																				unless clip[:opacity][:value].nil?
																					xmeml.filter {
																						xmeml.effect {
																							xmeml.name "Opacity"
																							xmeml.effectid "opacity"
																							xmeml.effectcategory "motion"
																							xmeml.effecttype "motion"
																							xmeml.mediatype "video"
																							xmeml.parameter {
																								xmeml.parameterid "opacity"
																								xmeml.name "opacity"
																								xmeml.value clip[:opacity][:value]
																								clip[:opacity][:keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value kf[:value]
																									}
																								end
																							}
																						}
																					}
																				end
																				clip[:marker_nodes].each do |marker|
																					xmeml << marker
																				end
																				xmeml << clip[:link_string] if add_link_string
																			}
																		end
																	when " transition"
																		xmeml.transitionitem {
																			xmeml.rate {
																				xmeml.ntsc sequence_settings[:ntsc]
																				xmeml.timebase sequence_settings[:timebase]
																			}
																			xmeml.start clip[:clipitem_start]
																			xmeml.end clip[:clipitem_end]
																			xmeml.alignment clip[:alignment]
																			xmeml.effect {
																				xmeml.name clip[:effectid]
																				xmeml.effectid clip[:effectid]
																				if clip[:effectid]=="Implode"
																					xmeml << clip[:effectcategory]
																				else
																					xmeml.effectcategory clip[:effectcategory]
																				end
																				xmeml.effecttype "transition"
																				xmeml.mediatype "video"
																			}
																		}
																	when "title"
																		xmeml.generatoritem(:id => clip[:clipitem_ids][0]) {
																			xmeml.name "Text"
																			xmeml.duration clip[:clip_duration]+1000
																			xmeml.rate {
																				xmeml.ntsc sequence_settings[:ntsc]
																				xmeml.timebase sequence_settings[:timebase]
																			}
																			xmeml.in clip[:clipitem_in]
																			xmeml.out clip[:clipitem_out]
																			xmeml.start clip[:clipitem_start]
																			xmeml.end clip[:clipitem_end]
																			xmeml.alphatype "black"
																			xmeml.enabled clip[:clip_enabled]
																			xmeml.effect {
																				xmeml.name "Outline Text"
																				xmeml.effectid "Outline Text"
																				xmeml.effectcategory "Text"
																				xmeml.effecttype "generator"
																				xmeml.mediatype "video"
																				xmeml.parameter {
																					xmeml.parameterid "str"
																					xmeml.name "Text"
																					value_node = "<value>#{clip[:src].gsub("\n", "&#13;")}</value>" # has to be added as text otherwise the & gets escaped
																					xmeml << value_node
																				}
																				unless clip[:text_style].nil?
																					xmeml.parameter {
																						xmeml.parameterid "font"
																						xmeml.name "Font"
																						xmeml.value clip[:text_style][:font]
																					}
																					xmeml.parameter {
																						xmeml.parameterid "size"
																						xmeml.name "Size"
																						xmeml.value clip[:text_style][:size]
																					}
																					xmeml.parameter {
																						xmeml.parameterid "style"
																						xmeml.name "Style"
																						xmeml.value clip[:text_style][:style]
																					}
																					xmeml.parameter {
																						xmeml.parameterid "align"
																						xmeml.name "Alignment"
																						xmeml.value clip[:text_style][:align]
																					}
																					xmeml.parameter {
																						xmeml.parameterid "textcolor"
																						xmeml.name "Text Color"
																						xmeml.value {
																							xmeml.alpha clip[:text_style][:font_alpha]
																							xmeml.red clip[:text_style][:font_red]
																							xmeml.green clip[:text_style][:font_green]
																							xmeml.blue clip[:text_style][:font_blue]
																						}
																					}
																					xmeml.parameter {
																						xmeml.parameterid "linewidth"
																						xmeml.name "Line Width"
																						xmeml.value clip[:text_style][:line_width]
																					}
																					xmeml.parameter {
																						xmeml.parameterid "linecolor"
																						xmeml.name "Line Color"
																						xmeml.value {
																							xmeml.alpha clip[:text_style][:line_alpha]
																							xmeml.red clip[:text_style][:line_red]
																							xmeml.green clip[:text_style][:line_green]
																							xmeml.blue clip[:text_style][:line_blue]
																						}
																					}
																					xmeml.parameter {
																						xmeml.parameterid "center"
																						xmeml.name "Center"
																						xmeml.value {
																							xmeml.horiz clip[:center][:value].first
																							xmeml.vert clip[:center][:value].last
																						}
																					}
																					xmeml.parameter {
																						xmeml.parameterid "lead"
																						xmeml.name "Leading"
																						xmeml.value clip[:text_style][:lead]
																					}
																					if clip[:text_style][:shadow]
																						xmeml.parameter {
																							xmeml.name "Drop Shadow"
																							xmeml.value "1"
																						}
																					end
																				end
																			}
																			################################
																			xmeml << clip[:timeremap_filter]
																			xmeml.filter {
																				xmeml.effect {
																					xmeml.effectid "basic"
																					xmeml.effectcategory "motion"
																					xmeml.effecttype "motion"
																					xmeml.mediatype "video"
																					if clip[:scale][:value]!=nil
																						xmeml.parameter {
																							xmeml.parameterid "scale"
																							xmeml.name "Scale"
																							xmeml.value clip[:scale][:value]
																							clip[:scale][:keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value kf[:value]
																								}
																							end
																						}
																					end
																					unless clip[:rotation][:value].nil?
																						xmeml.parameter {
																							xmeml.parameterid "rotation"
																							xmeml.name "Rotation"
																							xmeml.value clip[:rotation][:value]
																							clip[:rotation][:keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value kf[:value]
																								}
																							end
																						}
																					end
																				}
																			}
																			unless clip[:trim].nil?
																				xmeml.filter {
																					xmeml.effect {
																						xmeml.name "Crop"
																						xmeml.effectid "crop"
																						xmeml.effectcategory "motion"
																						xmeml.effecttype "motion"
																						xmeml.mediatype "video"
																						xmeml.parameter {
																							xmeml.parameterid "left"
																							xmeml.name "left"
																							xmeml.value clip[:trim][:left]
																							clip[:trim][:left_keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value kf[:value]
																								}
																							end
																						}
																						xmeml.parameter {
																							xmeml.parameterid "right"
																							xmeml.name "right"
																							xmeml.value clip[:trim][:right]
																							clip[:trim][:right_keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value kf[:value]
																								}
																							end
																						}
																						xmeml.parameter {
																							xmeml.parameterid "top"
																							xmeml.name "top"
																							xmeml.value clip[:trim][:top]
																							clip[:trim][:top_keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value kf[:value]
																								}
																							end
																						}
																						xmeml.parameter {
																							xmeml.parameterid "bottom"
																							xmeml.name "bottom"
																							xmeml.value clip[:trim][:bottom]
																							clip[:trim][:bottom_keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value kf[:value]
																								}
																							end
																						}
																					}
																				}
																			end
																			unless clip[:distort].nil?
																				xmeml.filter {
																					xmeml.effect {
																						xmeml.name "Distort"
																						xmeml.effectid "deformation"
																						xmeml.effectcategory "motion"
																						xmeml.effecttype "motion"
																						xmeml.mediatype "video"
																						xmeml.parameter {
																							xmeml.parameterid "ulcorner"
																							xmeml.name "Upper Left"
																							xmeml.value {
																								xmeml.horiz clip[:distort][:ulcorner].first
																								xmeml.vert clip[:distort][:ulcorner].last
																							}
																							clip[:distort][:ulcorner_keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value {
																										xmeml.horiz kf[:value].first
																										xmeml.vert kf[:value].last
																									}
																								}
																							end
																						}
																						xmeml.parameter {
																							xmeml.parameterid "urcorner"
																							xmeml.name "Upper Right"
																							xmeml.value {
																								xmeml.horiz clip[:distort][:urcorner].first
																								xmeml.vert clip[:distort][:urcorner].last
																							}
																							clip[:distort][:urcorner_keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value {
																										xmeml.horiz kf[:value].first
																										xmeml.vert kf[:value].last
																									}
																								}
																							end
																						}
																						xmeml.parameter {
																							xmeml.parameterid "lrcorner"
																							xmeml.name "Lower Right"
																							xmeml.value {
																								xmeml.horiz clip[:distort][:lrcorner].first
																								xmeml.vert clip[:distort][:lrcorner].last
																							}
																							clip[:distort][:lrcorner_keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value {
																										xmeml.horiz kf[:value].first
																										xmeml.vert kf[:value].last
																									}
																								}
																							end
																						}
																						xmeml.parameter {
																							xmeml.parameterid "llcorner"
																							xmeml.name "Lower Left"
																							xmeml.value {
																								xmeml.horiz clip[:distort][:llcorner].first
																								xmeml.vert clip[:distort][:llcorner].last
																							}
																							clip[:distort][:llcorner_keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value {
																										xmeml.horiz kf[:value].first
																										xmeml.vert kf[:value].last
																									}
																								}
																							end
																						}
																					}
																				}
																			end
																			unless clip[:opacity][:value].nil?
																				xmeml.filter {
																					xmeml.effect {
																						xmeml.name "Opacity"
																						xmeml.effectid "opacity"
																						xmeml.effectcategory "motion"
																						xmeml.effecttype "motion"
																						xmeml.mediatype "video"
																						xmeml.parameter {
																							xmeml.parameterid "opacity"
																							xmeml.name "opacity"
																							xmeml.value clip[:opacity][:value]
																							clip[:opacity][:keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value kf[:value]
																								}
																							end
																						}
																					}
																				}
																			end
																			################################
																			xmeml.sourcetrack {
																				xmeml.mediatype "video"
																			}
																			clip[:marker_nodes].each do |marker|
																				xmeml << marker
																			end
																		}
																	when "generator", "gap"
																		xmeml.clipitem(:id => clip[:clipitem_ids][0]) {
																			clip[:clipitem_ids].delete_at(0)
																			xmeml.name clip[:clip_name]
																			xmeml.duration clip[:clip_duration]+1000
																			xmeml.rate {
																				xmeml.ntsc sequence_settings[:ntsc]
																				xmeml.timebase sequence_settings[:timebase]
																			}
																			xmeml.in clip[:clipitem_in]
																			xmeml.out clip[:clipitem_out]
																			xmeml.start clip[:clipitem_start]
																			xmeml.end clip[:clipitem_end]
																			xmeml.logginginfo {
																				xmeml.description clip[:role]
																				xmeml.scene clip[:scene] unless clip[:scene].nil?
																				xmeml.shottake clip[:shot] unless clip[:shot].nil?
																				xmeml.lognote clip[:notes] unless clip[:notes].nil?
																			}
																			xmeml.enabled clip[:clip_enabled]
																			if clip[:color].nil?
																				xmeml.file(:id => clip[:clip_name] + " V#{t}f#{c}") {
																					xmeml.name "Slug"
																					xmeml.mediaSource "Slug"
																					xmeml.media {
																						xmeml.video {
																							xmeml.samplecharacteristics {
																								xmeml.width sequence_settings[:width]
																								xmeml.height sequence_settings[:height]
																							}
																						}
																						xmeml.audio
																					}
																				}
																			else # Color
																				clipitem = xmeml.doc.xpath("//clipitem").last
																				clipitem.name = "generatoritem"
																				xmeml.effect {
																					xmeml.name "Color"
																					xmeml.effectid "Color"
																					xmeml.effectcategory "Matte"
																					xmeml.effecttype "generator"
																					xmeml.mediatype "video"
																					xmeml.parameter {
																						xmeml.parameterid "fillcolor"
																						xmeml.name "Color"
																						xmeml.value {
																							xmeml.alpha 1
																							xmeml.red clip[:color][0]
																							xmeml.green clip[:color][1]
																							xmeml.blue clip[:color][2]
																						}
																					}
																				}
																				xmeml.filter {
																					xmeml.effect {
																						xmeml.effectid "basic"
																						xmeml.effectcategory "motion"
																						xmeml.effecttype "motion"
																						xmeml.mediatype "video"
																						if clip[:scale][:value]!=nil
																							xmeml.parameter {
																								xmeml.parameterid "scale"
																								xmeml.name "Scale"
																								xmeml.value clip[:scale][:value]
																								clip[:scale][:keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value kf[:value]
																									}
																								end
																							}
																						end
																						unless clip[:rotation][:value].nil?
																							xmeml.parameter {
																								xmeml.parameterid "rotation"
																								xmeml.name "Rotation"
																								xmeml.value clip[:rotation][:value]
																								clip[:rotation][:keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value kf[:value]
																									}
																								end
																							}
																						end
																						unless clip[:center][:value].nil?
																							xmeml.parameter {
																								xmeml.parameterid "center"
																								xmeml.name "Center"
																								xmeml.value {
																									xmeml.horiz clip[:center][:value].first
																									xmeml.vert clip[:center][:value].last
																								}
																								clip[:center][:keyframes].each do |kf|
																									xmeml.keyframe {
																										xmeml.when kf[:when]
																										xmeml.value {
																											xmeml.horiz kf[:value].first
																											xmeml.vert kf[:value].last
																										}
																									}
																								end
																							}
																						end
																					}
																				}
																			end
																			xmeml << clip[:timeremap_filter]
																			unless clip[:opacity][:value].nil?
																				xmeml.filter {
																					xmeml.effect {
																						xmeml.name "Opacity"
																						xmeml.effectid "opacity"
																						xmeml.effectcategory "motion"
																						xmeml.effecttype "motion"
																						xmeml.mediatype "video"
																						xmeml.parameter {
																							xmeml.parameterid "opacity"
																							xmeml.name "opacity"
																							xmeml.value clip[:opacity][:value]
																							clip[:opacity][:keyframes].each do |kf|
																								xmeml.keyframe {
																									xmeml.when kf[:when]
																									xmeml.value kf[:value]
																								}
																							end
																						}
																					}
																				}
																			end
																			clip[:marker_nodes].each do |marker|
																				xmeml << marker
																			end
																		}
																	when "ref-clip"
																		#puts "...add ref-clip"
																		clipitem_id = clip[:clipitem_ids][1] # sequence id, V id, A1 id, A2 id
																		xmeml.clipitem(:id => clip[:clipitem_ids][1]) {
																			xmeml.name clip[:clip_name]
																			xmeml.duration clip[:clip_duration]
																			xmeml.rate {
																				xmeml.ntsc sequence_settings[:ntsc]
																				xmeml.timebase sequence_settings[:timebase]
																			}
																			xmeml.in clip[:clipitem_in]
																			xmeml.out clip[:clipitem_out]
																			xmeml.start clip[:clipitem_start]
																			xmeml.end clip[:clipitem_end]
																			xmeml.sequence(:id => clip[:clipitem_ids][0])
																			xmeml.sourcetrack {
																				xmeml.mediatype "video"
																			}
																			clip[:marker_nodes].each do |marker|
																				xmeml << marker
																			end
																			xmeml.link {
																				xmeml.linkclipref "#{clipitem_id}"
																				xmeml.mediatype "video"
																			}
																			xmeml.link {
																				xmeml.linkclipref "#{clipitem_id} A1"
																				xmeml.mediatype "audio"
																			}
																			xmeml.link {
																				xmeml.linkclipref "#{clipitem_id} A2"
																				xmeml.mediatype "audio"
																			}
																		}
																	end
																end
															end
															last_track = xmeml.doc.xpath("//sequence/media/video/track").last
															unless last_track.element_children.empty?
																xmeml.enabled "TRUE"
															end
														}
													end
												}
											end
											unless ignore_all_audio
												xmeml.audio {
													xmeml.format {
														xmeml.samplecharacteristics {
															xmeml.depth "16"
															xmeml.samplerate sequence_settings[:samplerate]
														}
													}
													xmeml << sequence_settings[:outputs]
													xmeml.in "-1"
													xmeml.out "-1"
													seq_audios = seq[:audios]
													#puts "seq_audios.length = #{seq_audios.length}"
													if @roles_become_tracks
														#puts "seq audios:"
														# seq[:audios].each do |track|
														# 	#puts track.first[:role].inspect
														# 	if track.first[:role].nil?
														# 		#pp track.first
														# 	end
														# end
														seq_audios = seq[:audios].sort_by { |track| track.first[:role] } # sort audio roles alphabetically but do not sort video roles
													end
													seq_audios.each_with_index do |track, t|
														#puts "-------------------\nTrack A#{t+1} is #{track.first[:track_layout]} and has #{track.length} clips"
														max_audio_tracks = track.sort_by { |c| c[:tracks_array_length] }.last[:tracks_array_length]
														#puts "max_audio_tracks = #{max_audio_tracks}"
														max_audio_tracks.times do |i|
															options = {}
															if track.first[:track_layout]=="stereo"
																if i==0 || i==1
																	options = { "currentExplodedTrackIndex" => i, "totalExplodedTrackCount" => "2", "premiereTrackType" => "Stereo" }
																end
															elsif track.first[:track_layout]=="surround"
																if i==0 || i==1 || i==2 || i==3 || i==4 || i==5
																	options = { "currentExplodedTrackIndex" => i, "totalExplodedTrackCount" => "6", "premiereTrackType" => "5.1" }
																end
															end
															if @roles_become_tracks
																#puts "role: #{track.first[:role].inspect}", "roles: #{track.first[:roles].inspect}", "roles[#{i}] = #{track.first[:roles][i].inspect}"
																audio_role = track.first[:role]
																# if track.first[:track_layout]!="mono" && track.first[:roles]!=nil && track.first[:roles][i]!=nil
																if track.first[:roles]!=nil && track.first[:roles][i]!=nil
																	audio_role = track.first[:roles][i]
																end
																options["MZ.TrackName"] = audio_role
																options["TL.SQTrackExpandedHeight"] = "50"
																#puts "...and track name is #{audio_role}"
															end
															xmeml.track(options) {
																track.each_with_index do |clip, c|
																	add_this_clip = true
																	if @xmeml_sequence_options # single Project only
																		audio_role = clip[:role] if @roles_become_tracks==false # min tracks, so audio_role is nil otherwise
																		if clip[:role].nil? || selected_a_roles.include?(audio_role)
																			if @xmeml_enabled_only && clip[:audio_enableds]!=nil && clip[:audio_enableds][i]=="FALSE"
																				add_this_clip = false
																			end
																		else
																			add_this_clip = false
																		end
																	end
																	#puts " #{clip[:name]}, #{audio_role.inspect}: '#{clip[:clip_name]}' add_this_clip? #{add_this_clip}"
																	if add_this_clip
																		case clip[:name]
																		when "clip", "sync-clip", "clip synced"
																			#puts "  i = #{i}, clip[:tracks_array_length] = #{clip[:tracks_array_length]}"
																			if i < clip[:tracks_array_length] # check that there are still audio_tracks available
																				asset = @assets.find { |a| a[:id]==clip[:asset_id] }
																				unless asset.nil? #|| asset[:src].empty? # offline?
																					xmeml.clipitem(:id => clip[:clipitem_ids][0], :premiereChannelType => asset[:layout]) {
																						clip[:clipitem_ids].delete_at(0)
																						xmeml.name clip[:clip_name]
																						xmeml.duration clip[:clipitem_end] - clip[:clipitem_start] # bug fix for Audition
																						xmeml.rate {
																							xmeml.ntsc sequence_settings[:ntsc]
																							xmeml.timebase sequence_settings[:timebase]
																						}
																						if clip[:clipitem_start]>=0
																							xmeml.in clip[:clipitem_in]
																							xmeml.out clip[:clipitem_out]
																							xmeml.start clip[:clipitem_start]
																							xmeml.end clip[:clipitem_end]
																						else
																							xmeml.in clip[:clipitem_in] - clip[:clipitem_start]
																							xmeml.out clip[:clipitem_out]
																							xmeml.start "0"
																							xmeml.end clip[:clipitem_end]
																						end
																						xmeml.syncoffset clip[:syncoffset]
																						xmeml.logginginfo {
																							xmeml.description audio_role
																							xmeml.scene clip[:scene] unless clip[:scene].nil?
																							xmeml.shottake clip[:shot] unless clip[:shot].nil?
																							xmeml.lognote clip[:notes] unless clip[:notes].nil?
																						}
																						xmeml.comments {
																							xmeml.mastercomment1 clip[:mc1] unless clip[:mc1].nil?
																							xmeml.mastercomment2 clip[:mc2] unless clip[:mc2].nil?
																							xmeml.mastercomment3 clip[:mc3] unless clip[:mc3].nil?
																						}
																						if clip[:clip_enabled]=="FALSE" || clip[:audio_enableds][i]=="FALSE"
																							xmeml.enabled "FALSE"
																						else
																							xmeml.enabled "TRUE"
																						end
																						# xmeml.masterclipid clip[:clip_name] + " V#{t}m#{c}"
																						if asset[:used]
																							xmeml.file(:id => clip[:asset_id])
																						else
																							asset[:used] = true
																							xmeml.file(:id => clip[:asset_id]) {
																								xmeml.name asset[:name]
																								ntsc, timebase = to_ntsc_timebase(clip[:clip_frameDuration])
																								if File.extname(asset[:src]).downcase==".mp3"
																									ntsc = "TRUE"
																									timebase = 30
																								end
																								xmeml.rate {
																									xmeml.ntsc ntsc
																									xmeml.timebase timebase
																								}
																								if clip[:opt_src].nil? || clip[:opt_src].empty?
																									unless clip[:src].empty?
																										path = clip[:src].sub("file:///Users/", "file://localhost/Users/")
																										xmeml.pathurl path
																									end
																								else
																									path = clip[:opt_src].sub("file:///Users/", "file://localhost/Users/")
																									xmeml.pathurl path
																								end
																								xmeml.timecode {
																									xmeml.rate {
																										xmeml.ntsc ntsc #unless timebase==24
																										xmeml.timebase timebase
																									}
																									xmeml.string to_timecode(clip[:first_frame], timebase, clip[:displayformat])
																									xmeml.frame clip[:first_frame]
																									xmeml.source "source"
																									xmeml.displayformat clip[:displayformat]
																									if clip[:reel].nil?
																									else
																										xmeml.reel {
																											xmeml.name clip[:reel]
																										}
																									end
																								}
																								xmeml << clip[:media]
																							}
																						end
																						xmeml << clip[:timeremap_filter]
																						unless clip[:gains][i].nil? || @keep_audio_levels==false
																							xmeml.filter {
																								xmeml.effect {
																									xmeml.name "Audio Levels"
																									xmeml.effectid "audiolevels"
																									xmeml.effectcategory "audiolevels"
																									xmeml.effecttype "audiolevels"
																									xmeml.mediatype "audio"
																									xmeml.parameter {
																										xmeml.name "Level"
																										xmeml.parameterid "level"
																										xmeml.value clip[:gains][i]
																										unless clip[:gains][i]==0 || clip[:adj_gains_keytimes][i].nil?
																											clip[:adj_gains_keytimes][i].each_with_index do |kt, kv|
																												xmeml.keyframe {
																													xmeml.when kt
																													xmeml.value clip[:adj_gains_keyvalues][i][kv]
																												}
																											end
																										end
																									}
																								}
																							}
																						end
																						unless clip[:pans][i].nil?
																							xmeml.filter {
																								xmeml.effect {
																									xmeml.name "Audio Pan"
																									xmeml.effectid "audiopan"
																									xmeml.effectcategory "audiopan"
																									xmeml.effecttype "audiopan"
																									xmeml.mediatype "audio"
																									xmeml.parameter {
																										xmeml.name "Pan"
																										xmeml.parameterid "pan"
																										xmeml.value clip[:pans][i]
																										unless clip[:adj_panners_keytimes][i].nil?
																											clip[:adj_panners_keytimes][i].each_with_index do |kt, kv|
																												xmeml.keyframe {
																													xmeml.when kt
																													xmeml.value clip[:adj_panners_keyvalues][i][kv]
																												}
																											end
																										end
																									}
																								}
																							}
																						end
																						xmeml.sourcetrack {
																							xmeml.mediatype "audio"
																							xmeml.trackindex clip[:tracks_array][i]
																						}
																						clip[:marker_nodes].each do |marker|
																							xmeml << marker
																						end
																						xmeml << clip[:link_string] if add_link_string
																					}
																				end
																			else
																				#puts "  RUN OUT OF AUDIO CHANNELS - IGNORE"
																			end
																		when " transition"
																			if i < clip[:tracks_array_length] # check that there are still audio_tracks available
																				xmeml.transitionitem {
																					xmeml.rate {
																						xmeml.ntsc sequence_settings[:ntsc]
																						xmeml.timebase sequence_settings[:timebase]
																					}
																					xmeml.start clip[:clipitem_start]
																					xmeml.end clip[:clipitem_end]
																					xmeml.alignment clip[:alignment]
																					xmeml.effect {
																						xmeml.name "Cross Fade ( 0dB)"
																						xmeml.effectid "KGAudioTransCrossFade0dB"
																						xmeml.effecttype "transition"
																						xmeml.mediatype "audio"
																					}
																				}
																			end
																		when "ref-clip"
																			if i < clip[:tracks_array_length] # check that there are still audio_tracks available
																				clipitem_id = clip[:clipitem_ids][1]
																				xmeml.clipitem(:id => "#{clipitem_id} A#{i+1}") {
																					xmeml.name clip[:clip_name]
																					xmeml.duration clip[:clip_duration]
																					xmeml.rate {
																						xmeml.ntsc sequence_settings[:ntsc]
																						xmeml.timebase sequence_settings[:timebase]
																					}
																					xmeml.in clip[:clipitem_in]
																					xmeml.out clip[:clipitem_out]
																					xmeml.start clip[:clipitem_start]
																					xmeml.end clip[:clipitem_end]
																					xmeml.sequence(:id => clip[:clipitem_ids][0])
																					xmeml.sourcetrack {
																						xmeml.mediatype "audio"
																					}
																					clip[:marker_nodes].each do |marker|
																						xmeml << marker
																					end
																					xmeml.link {
																						xmeml.linkclipref "#{clipitem_id}"
																						xmeml.mediatype "video"
																					}
																					xmeml.link {
																						xmeml.linkclipref "#{clipitem_id} A1"
																						xmeml.mediatype "audio"
																					}
																					xmeml.link {
																						xmeml.linkclipref "#{clipitem_id} A2"
																						xmeml.mediatype "audio"
																					}
																				}
																			end
																		end
																	end
																end
																last_track = xmeml.doc.xpath("//sequence/media/audio/track").last
																if last_track.element_children.empty?
																	last_track.remove
																else
																	xmeml.enabled "TRUE"
																end
															}
														end
													end
												}
											end
										}
										sequence_settings[:marker_nodes].each do |marker|
											xmeml << marker
										end
									}
								end # unless sequence[:seq_id].nil?
							end # bin[:sequences].each
						} # xmeml.children
					} # xmeml.bin
					if @event_bins.length==1 && bin[:clips].empty? # single Project (with no Event clips) or old Project, so don't put the Sequence in a bin so that Audition/After Effects are happy
						single_bin = xmeml.doc.at_xpath("xmeml/bin")
						seqs = xmeml.doc.xpath("xmeml/bin/children/sequence")
						single_bin.swap(seqs)
					end
				end # @event_bins.each
			}
		end
		save_this_file = File.new(xml_file, "w")
		save_this_file.puts builder.to_xml(:indent => 2, :encoding => "UTF-8")
		save_this_file.close
	rescue => e
		if $ruby_cocoa==false
			raise
		else
			OSX::NSLog "#{e.message}\n#{e.backtrace.join("\n")}"
      executable = OSX::NSBundle.mainBundle.infoDictionary.objectForKey("CFBundleExecutable")
			version = OSX::NSBundle.mainBundle.infoDictionary.objectForKey("CFBundleShortVersionString")
			alert = OSX::NSAlert.alloc.init
			alert.setAlertStyle(OSX::NSInformationalAlertStyle)
			alert.setMessageText("There was a problem creating the translated XML#{@error_tracker}")
			alert.setInformativeText("Please zip up the .fcpxml file and email it with the subject “#{executable} #{version} error” to Xto7@assistedediting.com with this error message in the body text:\n
			#{e.message}\n
			#{e.backtrace.first}\n
			Thanks for helping us improve #{executable}!")
			alert.runModal
		end
	end
end

def save_project_srt(srt_file)
	# puts "------------------------------------------ save_project_srt"
	unless $ruby_cocoa==false
		# @progressIndicator.setIndeterminate(true)
		# @progressIndicator.setUsesThreadedAnimation(true)
		# @progressIndicator.startAnimation(self)
		# @progressMessage.setStringValue("Saving SRT...\n")
		# @progressIndicator.displayIfNeeded
		# @progressView.displayIfNeeded
	end
	begin
		srt_txt = ""
		@report_titles_generators.sort! { |c,d| c[:clipitem_start]==d[:clipitem_start]? c[:order]<=>d[:order] : c[:clipitem_start]<=>d[:clipitem_start] }
		@report_titles_generators.find_all { |t| t[:clip_name]=="Caption" }.each_with_index do |caption, i|
			millisecs = to_seconds(caption[:clipitem_start] - caption[:head_adj], @sequence_settings[:timebase]) * 1000.0
			srt_start = to_srt_timestamp(millisecs)
			millisecs = to_seconds(caption[:clipitem_end] + caption[:tail_adj], @sequence_settings[:timebase]) * 1000.0
			srt_end = to_srt_timestamp(millisecs)
			srt_txt << "#{i+1}\n"
			srt_txt << "#{srt_start} --> #{srt_end}\n"
			srt_txt << caption[:src]
			srt_txt << "\n\n"
		end
		unless srt_txt.empty?
			save_this_file = File.new(srt_file, "w")
			save_this_file.puts srt_txt
			save_this_file.close
		end
	rescue => e
		if $ruby_cocoa==false
			raise
		else
			OSX::NSLog "#{e.message}\n#{e.backtrace.join("\n")}"
      executable = OSX::NSBundle.mainBundle.infoDictionary.objectForKey("CFBundleExecutable")
			version = OSX::NSBundle.mainBundle.infoDictionary.objectForKey("CFBundleShortVersionString")
			alert = OSX::NSAlert.alloc.init
			alert.setAlertStyle(OSX::NSInformationalAlertStyle)
			alert.setMessageText("There was a problem creating the SRT#{@error_tracker}")
			alert.setInformativeText("Please zip up the .fcpxml file and email it with the subject “#{executable} #{version} SRT error” to Xto7@assistedediting.com with this error message in the body text:\n
			#{e.message}\n
			#{e.backtrace.first}\n
			Thanks for helping us improve #{executable}!")
			alert.runModal
		end
	end
end
